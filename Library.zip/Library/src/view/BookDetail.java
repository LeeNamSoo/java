package view;

public class BookDetail {

}
